﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.VFX;

public class Controller : MonoBehaviour
{
    public Rigidbody rigidbody;

    [Header("Basic Settings")]
    public AnimationCurve accelerationCurve;
    public AnimationCurve thrustAccelerationCurve;
    public float maxSpeed = 10;
    public Vector2 minMaxTurnAngle = new Vector2(12.5f, 30);
    public Vector3 centerOfMass = Vector3.zero;

    [Header("Wheels and spring")]
    public List<Wheel> forwardWheels;
    public List<Wheel> rearWheels;
    
    public float forwardWheelsFriction = 1.1f;
    public float rearWheelsFriction = 1f;
    public float forwardWheelsFrictionOnDrift = 0.8f;
    public float rearWheelsFrictionOnDrift = 0.5f;

    [Header("Air Tricks")]
    public float trickTime = 1.5f;
    public float upsideDownRay = 1;
    public float thrustForce = 20;
    public float jumpForce = 10;
    public float rollImpulseForce = 10;
    public float airRotationSpeed = 1;
    public float totalRotationOnTrick = 300;

    public VisualEffect particles;
    public VisualEffect[] tireTrails;

    //PRIVATE STUFF
    private bool grounded = false;

    private bool isPerformingAirTrick = false;
    private float trickTimeCounter = 0;
    private Vector3 trickDirection;


    private void Start()
    {
        rigidbody.maxAngularVelocity = float.PositiveInfinity;
    }

    private void Update()
    {
        grounded = forwardWheels.FindIndex(x => x.grounded) != -1|| rearWheels.FindIndex(x => x.grounded) != -1;
        
        rigidbody.centerOfMass = centerOfMass;

        float steeringAngle = GetSteeringAngle();
        for (int i = 0; i < forwardWheels.Count; i++)
        {
            forwardWheels[i].transform.localEulerAngles = new Vector3(0, steeringAngle, 0);
        }

        UpdateDrift();
        UpdateFireEffect();
        AirTricks();

        //air rotation
        if (!grounded && !isPerformingAirTrick)
        {
            var tilt = 0f;
            tilt += Input.GetKey(KeyCode.E) ? 1 : 0;
            tilt += Input.GetKey(KeyCode.Q) ? -1 : 0;
            var rotation = new Vector3(Input.GetAxisRaw("Vertical"), Input.GetAxisRaw("Horizontal"), -tilt);
            rigidbody.AddRelativeTorque(rotation * airRotationSpeed, ForceMode.Acceleration);
        }
    }

    private float GetSteeringAngle()
    {
        var steringPosition = Mathf.InverseLerp(-1, 1, Input.GetAxis("Horizontal"));
        var angleDelta = Mathf.InverseLerp(0, maxSpeed, rigidbody.velocity.magnitude);
        var turnAngle = Mathf.Lerp(minMaxTurnAngle.y, minMaxTurnAngle.x, angleDelta);
        var angle = Mathf.Lerp(-turnAngle, turnAngle, steringPosition);
        return angle;
    }

    private float GetAcceleration(Wheel wheel)
    {
        if (Input.GetKey(KeyCode.LeftShift))
            return 0;

        float input = Input.GetAxis("Vertical");
        var velocity = rigidbody.velocity;

        var isMovingForward = Vector3.Dot(transform.forward, velocity.normalized) > 0;
        var isBreaking = (input < 0 && isMovingForward) || (input > 0 && !isMovingForward);

        var forwardVelocity = Vector3.Project(velocity, wheel.transform.forward);
        var acceleration = isBreaking ? accelerationCurve.keys[0].value : accelerationCurve.Evaluate(forwardVelocity.magnitude);
        return acceleration / forwardWheels.Count * input; //divide acceleration between each wheel
    }

    private void UpdateFireEffect()
    {
        var isFireEffectEnabled = rigidbody.velocity.magnitude > maxSpeed * .8f;
        for (int i = 0; i < rearWheels.Count; i++)
        {
            if (rearWheels[i].grounded && isFireEffectEnabled)
            {
                tireTrails[i].SetInt("emission", 1000);
            }
            else
                tireTrails[i].SetInt("emission", 0);
        }
    }

    private void FixedUpdate()
    {
        for (int i = 0; i < forwardWheels.Count; i++)
        {
            var acceleration = GetAcceleration(forwardWheels[i]);
            forwardWheels[i].SetAcceleration(acceleration);
        }

        if (Input.GetKey(KeyCode.LeftShift))
        {
            var thrustForce = grounded ? thrustAccelerationCurve.Evaluate(rigidbody.velocity.magnitude) : this.thrustForce;
            rigidbody.AddForce(transform.forward * thrustForce, ForceMode.Acceleration);
            particles.SetInt("SpawnRate", 3000);
        }
        else
            particles.SetInt("SpawnRate", 0);

        LimitVelocity();
        HandleGravity();
        HandleTrickRoll();
    }

    private void UpdateDrift()
    {
        foreach (var wheel in forwardWheels)
        {
            //reduce friction on wheel on press M to drift car
            if (Input.GetKey(KeyCode.M))
                wheel.frictionMultiplier = forwardWheelsFrictionOnDrift;
            else
                wheel.frictionMultiplier = forwardWheelsFriction;
        }

        foreach (var wheel in rearWheels)
        {
            //reduce friction on wheel on press M to drift car
            if (Input.GetKey(KeyCode.M))
                wheel.frictionMultiplier = rearWheelsFrictionOnDrift;
            else
                wheel.frictionMultiplier = rearWheelsFriction;
        }
    }

    private void LimitVelocity()
    {
        Vector3 velocity = rigidbody.velocity;
        var clampedVelocity = Vector3.ClampMagnitude(velocity, maxSpeed);
        rigidbody.velocity = clampedVelocity;
    }

    private void HandleGravity()
    {
        if (grounded)
        {
            rigidbody.useGravity = false;
            rigidbody.AddForce(transform.up * Physics.gravity.y * 0.9f);
        }
        else
        {
            if (!isPerformingAirTrick)
                rigidbody.useGravity = true;
        }
    }

    private void HandleTrickRoll()
    {
        if (!isPerformingAirTrick)
            return;

        var angle = (totalRotationOnTrick / trickTime) * Time.fixedDeltaTime;
        var rotation = Quaternion.AngleAxis(angle, trickDirection);
        rigidbody.rotation = transform.rotation * rotation;
    }

    private void AirTricks()
    {
        if (isPerformingAirTrick)
        {
            trickTimeCounter += Time.deltaTime;
            if (trickTimeCounter > trickTime)
            {
                trickTimeCounter = 0;
                isPerformingAirTrick = false;
                rigidbody.constraints = RigidbodyConstraints.None;

                //add continuous movement
                var angle = (totalRotationOnTrick / trickTime) * Time.fixedDeltaTime;
                // var rotation = Quaternion.AngleAxis(angle, trickDirection);
                rigidbody.angularVelocity = transform.rotation * trickDirection * angle;
            }
            else
            {
                return;
            }
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (grounded)
                rigidbody.AddForce(transform.up * jumpForce, ForceMode.Impulse);
            else
            {
                //FLIP THE CAR IF IS UPSIDE DOWN ON THE GROUND
                bool isUpsideDown = Vector3.Dot(transform.up, Vector3.up) < 0;
                if (isUpsideDown)
                {
                    Ray ray = new Ray(transform.position, transform.up);
                    RaycastHit hit;

                    if (Physics.Raycast(ray, out hit, upsideDownRay, -1))
                    {
                        rigidbody.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
                        rigidbody.AddRelativeTorque(new Vector3(0, 0, 1) * 8, ForceMode.Impulse);
                        return;
                    }
                }


                var direction = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical")).normalized;

                if (direction.magnitude <= Vector3.kEpsilon) //DO THE SECOND JUMP
                {
                    rigidbody.AddForce(transform.up * jumpForce, ForceMode.Impulse);
                }
                else //START TRICK
                {
                    isPerformingAirTrick = true;

                    //remove vertical velocity and turn off gravity - like rocket league
                    rigidbody.constraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezeRotation;

                    var horizontalForward = transform.forward;
                    horizontalForward.y = 0;
                    horizontalForward.Normalize();

                    var horizontalRight = Quaternion.Euler(0, 90, 0) * horizontalForward;

                    var forwardForce = horizontalForward * Input.GetAxisRaw("Vertical");
                    var sideForce = horizontalRight * Input.GetAxisRaw("Horizontal");

                    rigidbody.AddForce((forwardForce + sideForce) * rollImpulseForce, ForceMode.Impulse);
                    trickDirection = new Vector3(Input.GetAxisRaw("Vertical"), 0, -Input.GetAxisRaw("Horizontal")).normalized;
                }
            }
        }
    }

    void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(transform.position + centerOfMass, 0.2f);
        Gizmos.DrawLine(transform.position, transform.position + transform.up * upsideDownRay);
    }
}
