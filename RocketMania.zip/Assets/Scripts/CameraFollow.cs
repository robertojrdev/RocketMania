﻿using UnityEngine;

public class CameraFollow : MonoBehaviour
{

    public Transform car;
    public Transform ball;
    public bool ballMode = true;

    [Header("Car mode settings")]
    public float heightOffset = 1;
    public float distance = 5;
    public float height = 1;
    public float smoothSpeed = 0.5f;
    public float carVelocityThreshold = 0.5f;

    [Header("Ball mode settings")]
    public float heightOffsetB = 1;
    public float distanceB = 5;
    public float smoothSpeedB = 0.5f;
    public float lookSmoothSpeedB = 0.5f;
    public LayerMask avoidingMask = -1;

    private Vector3 smoothDampVelocity;
    private Vector3 lookBallSmoothDampVelocity;
    private Vector3 carLastPosition;
    private bool followingCarMovement = false;
    private Vector3 lokingPosition;
    private void LateUpdate()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            ballMode = !ballMode;
            lookBallSmoothDampVelocity = Vector3.zero;
            smoothDampVelocity = Vector3.zero;
        }

        if (ballMode)
            BallMode();
        else
            CarMode();
    }

    private void BallMode()
    {
        var middlePoint = car.position + Vector3.up * heightOffsetB;
        var direction = middlePoint - ball.position;
        direction.Normalize();
        var desiredPosition = middlePoint + direction * distanceB;

        Ray ray = new Ray(middlePoint, direction);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit, distance, avoidingMask))
        {
            if(Vector3.Dot(hit.normal, Vector3.up) > 0.9f)
                desiredPosition = hit.point - direction * 0.1f + Vector3.up * heightOffset * 1.5f;
        }

        transform.position = Vector3.SmoothDamp(transform.position, desiredPosition, ref smoothDampVelocity, smoothSpeedB);
        lokingPosition = Vector3.SmoothDamp(lokingPosition, ball.position, ref lookBallSmoothDampVelocity, lookSmoothSpeedB);
        transform.LookAt(lokingPosition);
    }

    private void CarMode()
    {
        var carMovement = car.position - carLastPosition;

        if (followingCarMovement)
        {
            if (carMovement.magnitude < carVelocityThreshold - 0.1f)
                followingCarMovement = false;
        }
        else
        {
            if (carMovement.magnitude > carVelocityThreshold + 0.1f)
                followingCarMovement = true;
        }

        if (followingCarMovement)
            carMovement.Normalize();
        else
            carMovement = car.forward;

        carLastPosition = car.position;

        var lookPosition = car.position + Vector3.up * heightOffset;
        var desiredPosition = car.position - carMovement * distance + Vector3.up * height;

        transform.position = Vector3.SmoothDamp(transform.position, desiredPosition, ref smoothDampVelocity, smoothSpeed);
        transform.LookAt(lookPosition);
    }
}
