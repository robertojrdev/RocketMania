﻿using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Airplane : MonoBehaviour
{
    public float thrustForce = 1;
    public float pitchForce = 1;
    public float yawForce = 1;
    public Vector3 centerOfMass = Vector3.zero;
    public float wingArea = 16;
    public float wingSpan = 12;
    public Vector3 elevatorOffset = Vector3.one;

    private Rigidbody rigidbody;
    private Vector3 liftForce;
    private Vector3 dragForce;
    private float velocityKMH;
    private float velocityKNOTS;

    private void Awake()
    {
        rigidbody = GetComponent<Rigidbody>();
    }

    private void FixedUpdate()
    {
        rigidbody.centerOfMass = centerOfMass;

        var thrust = Input.GetKey(KeyCode.W) ? 1 : Input.GetKey(KeyCode.S) ? -1 : 0;
        rigidbody.AddForce(transform.forward * thrustForce * thrust, ForceMode.Force);

        var pitch = Input.GetKey(KeyCode.UpArrow) ? 1 : Input.GetKey(KeyCode.DownArrow) ? -1 : 0;
        rigidbody.AddRelativeTorque(Vector3.right * pitchForce * pitch);
        var row = Input.GetKey(KeyCode.A) ? 1 : Input.GetKey(KeyCode.D) ? -1 : 0;
        rigidbody.AddRelativeTorque(Vector3.forward * pitchForce * row);
        var yaw = Input.GetKey(KeyCode.LeftArrow) ? -1 : Input.GetKey(KeyCode.RightArrow) ? 1 : 0;
        rigidbody.AddRelativeTorque(Vector3.up * yawForce * yaw);


        var localVelocity = transform.InverseTransformDirection(rigidbody.velocity);
        var angleOfAttack = Mathf.Atan2(-localVelocity.y, localVelocity.z);

        var aspectRatio = (wingSpan * wingSpan) / wingArea;
        var inducedLift = angleOfAttack * (aspectRatio / (aspectRatio + 2f)) * 2f * Mathf.PI;
        var inducedDrag = (inducedLift * inducedLift) / (aspectRatio * Mathf.PI);

        var pressure = rigidbody.velocity.sqrMagnitude * 1.2754f * 0.5f * wingArea;

        var lift = inducedLift * pressure;
        var drag = (0.021f + inducedDrag) * pressure;


        dragForce = rigidbody.velocity.normalized;
        liftForce = Vector3.Cross(dragForce, transform.right);

        rigidbody.AddForce(liftForce * lift - dragForce * drag);

        var angle = Vector3.SignedAngle(transform.forward, rigidbody.velocity.normalized, transform.up);
        if(Mathf.Abs(angle) < 50 && rigidbody.velocity.magnitude > 5f)
        rigidbody.AddRelativeTorque(Vector3.up * angle * drag);

        velocityKMH = rigidbody.velocity.magnitude * 3.6f;
        velocityKNOTS = velocityKMH * 0.54f;
    }

    private void OnDrawGizmos()
    {
        var centerOfMass = GetOffsetPosition(this.centerOfMass);
        Gizmos.DrawWireSphere(centerOfMass, 0.5f);

        Gizmos.color = Color.green;
        Gizmos.DrawLine(transform.position, transform.position + liftForce);

        Gizmos.color = Color.red;
        Gizmos.DrawLine(transform.position, transform.position + dragForce);

        var elevatorPosition = GetOffsetPosition(elevatorOffset);
        Gizmos.DrawWireSphere(elevatorPosition, 0.5f);
    }

    private Vector3 GetOffsetPosition(Vector3 offset)
    {
        var position = transform.position;
        position += transform.forward * offset.z;
        position += transform.right * offset.x;
        position += transform.up * offset.y;

        return position;
    }

}
