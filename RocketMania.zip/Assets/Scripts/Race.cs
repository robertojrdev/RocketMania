﻿using System;
using UnityEngine;
using UnityEngine.UI;

public class Race : MonoBehaviour
{
    public Text currentLapTimeText;
    public Text bestLapTimeText;
    public Text lapsCountText;
    public CheckPoint[] checkPoints;

    private int _currentCheckPoint = -1;

    private float lapStartTime = 0;
    private float bestLapTime = float.MaxValue;
    private int lapsCount = 0;

    private void Start()
    {
        for (int i = 0; i < checkPoints.Length; i++)
        {
            checkPoints[i].Subscribe(this, i);
        }
    }

    private void Update() 
    {
        if(_currentCheckPoint != -1)
        {
            currentLapTimeText.text = "Current " + Math.Round(Time.timeSinceLevelLoad - lapStartTime, 2);
        }    
    }

    public void PassOnCheckPoint(int index)
    {
        if (_currentCheckPoint == -1 && index == 0)
        {
            StartRace();
        }
        else if (index == (_currentCheckPoint + 1) % checkPoints.Length)
        {
            NextCheckPoint();
        }
    }

    private void NextCheckPoint()
    {
        _currentCheckPoint = (_currentCheckPoint + 1) % checkPoints.Length;
        if(_currentCheckPoint == 0)
            NextLap();
    }

    private void NextLap()
    {
        var lapTime = Time.timeSinceLevelLoad - lapStartTime;
        if(bestLapTime >  lapTime)
            bestLapTime = lapTime;

        lapStartTime = Time.timeSinceLevelLoad;

        bestLapTimeText.text = "Best lap " + Math.Round(bestLapTime, 2);
        lapsCount++;
        lapsCountText.text = "Lap " + lapsCount;
        
    }

    private void StartRace()
    {
        _currentCheckPoint = 0;
        lapStartTime = Time.timeSinceLevelLoad;
        lapsCountText.text = "Lap " + lapsCount;
    }
}
