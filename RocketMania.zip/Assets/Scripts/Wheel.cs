using UnityEngine;

public class Wheel : MonoBehaviour
{
    public Rigidbody rigidbody;
    public float wheelDistance = 0.5f;
    [Range(0, 1)] public float minWheelDistance = 0.5f;
    public float springForce = 1;
    public float wheelRadius = 0.5f;
    public float counterSpringForce = 2;
    public float counterSpringForceMaxForce = 100;
    public AnimationCurve wheelForceCurve;
    public AnimationCurve wheelFrictionCurve;
    public float frictionMultiplier = 1;
    public Transform mesh;
    public bool debugForces = true;

    public float wheelLastDistance { get; private set; }
    public Vector3 wheelLastPosition { get; private set; }
    public Vector3 wheelForwardVelocity { get; private set; }
    public bool grounded { get; private set; }

    private float acceleration;
    private Vector3 driftForce;
    private Vector3 wheelSpringForce;
    private Vector3 bouncynessReduction;

    public void SetAcceleration(float acceleration)
    {
        this.acceleration = acceleration;
    }

    private void Start()
    {
        wheelLastPosition = transform.position;
    }

    private void Update()
    {
        //Rotate Mesh
        float spinAngle = wheelForwardVelocity.magnitude * (Mathf.PI * wheelRadius * Mathf.PI * wheelRadius);

        if (Vector3.Dot(transform.forward, wheelForwardVelocity) > 0)
            spinAngle = -spinAngle;

        mesh.RotateAroundLocal(Vector3.right, spinAngle);

        if (debugForces)
            DebugForces();

    }

    private void DebugForces()
    {
        if (!grounded)
            return;

        //debug friction
        var deltaColor = Mathf.InverseLerp(0, wheelFrictionCurve.keys[wheelFrictionCurve.keys.Length - 1].time, driftForce.magnitude);
        Debug.DrawLine(mesh.position, mesh.position + driftForce * 3, Color.Lerp(Color.green, Color.red, deltaColor));

        //debug acceleration
        Debug.DrawLine(mesh.position, mesh.position + acceleration * transform.forward * 0.1f, Color.blue);

        //debug spring
        Debug.DrawLine(mesh.position, mesh.position + wheelSpringForce * 0.1f, Color.yellow);

        //debug bouncyness reduction
        Debug.DrawLine(mesh.position, mesh.position + Vector3.right * .02f - bouncynessReduction * 0.1f, Color.red);

        //debug min distance
        Debug.DrawLine(transform.position, transform.position - transform.up * wheelDistance * minWheelDistance, Color.red);

    }

    private void FixedUpdate()
    {
        Ray ray = new Ray(transform.position, -transform.up);
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit, wheelDistance, -1, QueryTriggerInteraction.Ignore))
        {
            float minDist = wheelDistance * minWheelDistance;
            float hitDist = hit.distance;
            // if (hitDist < minDist)
            // {
            //     var currentDirection = hit.point - rigidbody.transform.position;
            //     var desiredWheelPosition = transform.position - (transform.up * minDist);
            //     var positionDirection = desiredWheelPosition - rigidbody.transform.position;

            //     Debug.DrawLine(rigidbody.transform.position, rigidbody.transform.position + positionDirection, Color.cyan);
            //     Debug.DrawLine(rigidbody.transform.position, rigidbody.transform.position + currentDirection, Color.cyan);

            //     Debug.DrawLine(rigidbody.transform.position, rigidbody.transform.position + rigidbody.transform.forward, Color.magenta);

            //     var angle = Vector3.Angle(positionDirection, desiredWheelPosition);
            //     var rotation = Quaternion.FromToRotation(positionDirection.normalized, currentDirection.normalized);
            //     rigidbody.transform.rotation *= rotation;
            //     rigidbody.transform.position = (rigidbody.transform.position - (ray.direction * (minDist - hitDist)));

            //     Debug.DrawLine(rigidbody.transform.position, rigidbody.transform.position + rigidbody.transform.forward, Color.yellow);


            //     // hitDist = minDist;
            //     // return;
            // }

            grounded = true;
            var force = Vector3.zero;
            var forward = transform.forward;
            var position = transform.position;

            var forceIntensity = Mathf.InverseLerp(wheelDistance, 0, hitDist);
            forceIntensity = wheelForceCurve.Evaluate(forceIntensity);
            wheelSpringForce = springForce * -ray.direction * forceIntensity;

            force += wheelSpringForce;  //add srping force

            var deltaPosition = wheelLastPosition - position;
            driftForce = Vector3.Project(deltaPosition, transform.right);
            var frictionForce = driftForce * wheelFrictionCurve.Evaluate(driftForce.magnitude);

            force += frictionForce * frictionMultiplier;

            //add lost drift velocity to forward movement - this will keep the velocity on curves
            force += forward * driftForce.magnitude * 2;

            wheelForwardVelocity = Vector3.Project(deltaPosition, forward); //set forward velocity to use on wheel rotation

            var distanceDelta = wheelLastDistance - hitDist;
            bouncynessReduction = distanceDelta * wheelSpringForce * counterSpringForce;
            bouncynessReduction = Vector3.ClampMagnitude(bouncynessReduction, counterSpringForceMaxForce);
            force += bouncynessReduction; //reduces bouncyness

            wheelLastDistance = hitDist;

            force += forward * acceleration; //add torque

            rigidbody.AddForceAtPosition(force, position, ForceMode.Force); //apply force


            //update mesh
            mesh.transform.position = hit.point - ray.direction * wheelRadius;
        }
        else
        {
            grounded = false;
            wheelLastDistance = wheelDistance;

            //update mesh
            mesh.transform.position = transform.position + ray.direction * (wheelDistance - wheelRadius);
        }

        wheelLastPosition = transform.position;

    }

    private bool firstValidade = true;
    private void OnValidate()
    {
        if (firstValidade)
        {
            firstValidade = false;

            var mesh = GetComponentInChildren<MeshRenderer>();
            if (mesh != null)
                this.mesh = mesh.transform;
        }
    }
}