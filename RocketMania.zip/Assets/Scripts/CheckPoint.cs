using System;
using UnityEngine;

public class CheckPoint : MonoBehaviour
{
    private Race race;
    private int index = -1;

    internal void Subscribe(Race race, int i)
    {
        this.race = race;
        index = i;
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Car"))
        {
            if(race)
                race.PassOnCheckPoint(index);
        }
    }
}